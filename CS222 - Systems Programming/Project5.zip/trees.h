#include <string.h>
#include "Student.h"
#include <stdlib.h>

Student* insert(Student* root, Student* node){
  if(root == NULL)
    root = node;

  else{
    if( strcmp(node->last, root->last) < 0)
      root->left = insert(root->left, node);
    else if( strcmp(node->last, root->last) > 0)
      root->right = insert(root->right, node);

    else
      return NULL;
  }
  return root;
}

  
Student* search(Student* root, char* first, char* last){
  if(root == NULL)
    return NULL;

  //checks for cases of students with same last name on the roster
  else if(strcmp(last, root->last) == 0 && strcmp(first, root->first) == 0)
    return root;
  else if(strcmp(last, root->last) < 0 || (strcmp(last, root->last) == 0 && strcmp(first, root->first) < 0))
    return search(root->left, first, last);
  else if(strcmp(last, root->last) > 0 || (strcmp(last, root->last) == 0 && strcmp(first, root->first) > 0))
    return search(root->right, first, last);
}

Student* delete(Student** root, char* first, char* last){

}

