#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Student.h"
#include "trees.h"
#include <ctype.h>

int validHouse(char* house){
  int i=0, houseFlag=0;
  House houseName;
  

  return houseFlag;
}

void helpMenu();
void add(char* firstName, char* lastName, int points, int year, House house);
void find(char* firstName, char* lastName, House house);

Student* gryffRoot = NULL;
Student* ravenRoot = NULL;
Student* huffleRoot = NULL;
Student* slythRoot = NULL;
Student* deceasedRoot = NULL;

int main(){
  //used to check if the specified house is a valid house
  int houseFlag;
  char* command = malloc(sizeof(char)*100);  
  do{
    houseFlag=0;
    printf("Enter command: ");
    scanf("%s", command);

    //prints out the help menu
    if(strcmp(command, "help")==0){
      FILE* helpMenu = fopen("help.txt", "r");
      char fileRead = fgetc(helpMenu);

      while(fileRead != EOF){
	printf("%c", fileRead);
	fileRead = fgetc(helpMenu);
      }
      printf("\n");
    }
    //loads a specified file into the roster
    else if(strcmp(command, "load")==0){
      char fileName[100];
      scanf("%s", fileName);
      FILE* file = fopen(fileName, "r");

      while(fgetc(file) != EOF){
	char* firstName = malloc(sizeof(char)*100);
	char* lastName = malloc(sizeof(char)*100);
	int points;
	int year;
	char* house;
	fscanf(file, "%s", firstName);
	fscanf(file, "%s", lastName);
	fscanf(file, "%d", &points);
	fscanf(file, "%d", &year);
	fscanf(file, "%s", house);

	int i=0;
	House houseName;
	for(;i<HOUSES;i++){
	  if( strcmp(house, HOUSE_NAMES[i]) == 0){
	    houseName = i;
	    houseFlag = 1;
	  }
	}

	if(houseFlag == 1)
	  add(firstName, lastName, points, year, houseName);
	else
	  printf("Something bad\n");
      }
      printf("Something happened\n");
    }
    else if(strcmp(command, "save")==0){
      
    }

    else if(strcmp(command, "clear")==0){
      
    }

    else if(strcmp(command, "inorder")==0){
      
    }
    else if(strcmp(command, "preorder")==0){
      
    }
    else if(strcmp(command, "postorder")==0){
      
    }
    else if(strcmp(command, "add")==0){
      char* firstName = malloc(sizeof(char) * 100);
      scanf("%s", firstName);

      char* lastName = malloc(sizeof(char) * 100);
      scanf("%s", lastName);

      int points;
      scanf("%d", &points);

      int year;
      scanf("%d", &year);
      
      char* house = malloc(sizeof(char) * 100);
      scanf("%s", house);

      int i=0;
      House houseName;
      
      for(;i<HOUSES;i++)
	if(strcmp(house, HOUSE_NAMES[i]) == 0){
	  houseName = i;
	  houseFlag=1;
	}

      if(houseFlag == 1)	
	add(firstName, lastName, points, year, houseName);
      
      free(firstName);
      free(lastName);
      free(house);
    }
    else if(strcmp(command, "kill")==0){
      
    }
    else if(strcmp(command, "find")==0){
      char* fName = malloc(sizeof(char) * 100);
      char* lName = malloc(sizeof(char) * 100);
      char* house = malloc(sizeof(char) * 100);
      
      scanf("%s", fName);
      scanf("%s", lName);
      scanf("%s", house);

      int i=0;
      House houseName;
      
      for(;i<HOUSES;i++)
	if(strcmp(house, HOUSE_NAMES[i]) == 0)
	  houseName = i;
      
      find(fName, lName, houseName);

      free(fName);
      free(lName);
      free(house);
    }
    else if(strcmp(command, "points")==0){
      
    }
    else if(strcmp(command, "score")==0){
      
    }

    //prints if specified command is unknown
    else if(strcmp(command, "quit") != 0)
      printf("Unknown command: <%s>\n", command);
  }while(strcmp(command, "quit") != 0);

  printf("All data cleared\n");
  //clear();
  return 0;
}

void add(char* firstName, char* lastName, int points, int year, House house){
  Student* node = malloc(sizeof(Student));
  node->first = firstName;
  node->last = lastName;
  node->points = points;
  node->year = year;
  node->house = house;
  
  switch(house){
  case 0:
    gryffRoot = insert(gryffRoot, node);
    break;
  case 1:
    ravenRoot = insert(ravenRoot, node);
    break;
  case 2:
    huffleRoot = insert(huffleRoot, node);
    break;
  case 3:
    slythRoot = insert(slythRoot, node);
    break;
  }
}

void find(char* firstName, char* lastName, House house){
  Student* temp;
  switch(house){
  case 0:
    temp = search(gryffRoot, firstName, lastName);
    break;
  case 1:
    temp = search(ravenRoot, firstName, lastName);
    break;
  case 2:
    temp = search(huffleRoot, firstName, lastName);
    break;
  case 3:
    temp = search(slythRoot, firstName, lastName);
    break;  
  }

  printf("%s %s\t\tPoints: %d\tYear: %d House: %s\n", firstName, lastName, temp->points, temp->year, HOUSE_NAMES[temp->house]);
}
