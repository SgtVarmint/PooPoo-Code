
public class InvalidOperandException extends Exception {

}
