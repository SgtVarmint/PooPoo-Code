
public class UnbalancedLeftParenthesesException extends Exception {

}
