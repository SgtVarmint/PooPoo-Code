
public class InvalidOperatorException extends Exception {

}
