
public class UnbalancedRightParenthesesException extends Exception {

}
